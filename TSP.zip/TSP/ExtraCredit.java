/******************************************************************************
  * Erica Portnoy
  * login: eportnoy
  * Precept: P02C
  * assignment 8
  * 
  * Compilation: javac ExtraCredit.java
  * Execution: java ExtraCredit
  * Dependencies: StdOut.java, Point.java, StdDraw.java
  * 
  * Explanation: Represents the sequence of points visited in a TSP tour.
  ******************************************************************************/
public class ExtraCredit {
  
  private Node first;
  private Node data;
  
  private int k;
  
  private class Node {
    private Point p;
    private Node next;
    private Node[] neighbors;
    
    public void createNeighbor() {
      if (size() < 10) return;
      
      if (k > size() - 1) throw new RuntimeException("k too large");
      neighbors = new Node[k];
      
      if (first != null) {
        
        for (int i = 0; i < k; i++) {
          double close = Double.POSITIVE_INFINITY;
          Node now = first.next;
          Node closeNode = null;
          while (now != first) {
            double curDist = now.p.distanceTo(this.p);
            if (curDist != 0 && curDist < close) {
              if (i == 0) {
                close = curDist;
                closeNode = now;
              }
              else if (curDist > this.p.distanceTo(neighbors[i-1].p)) {
                close = curDist;
                closeNode = now;
              }
            }
            now = now.next;
          }
          double curDist = now.p.distanceTo(this.p);
          if (curDist != 0 && curDist < close) {
            if (i == 0) {
              close = curDist;
              closeNode = now;
            }
            else if (curDist > this.p.distanceTo(neighbors[i-1].p)) {
              close = curDist;
              closeNode = now;
            }
          }
          neighbors[i] = closeNode;
        }
      }
      
    }
  }
  
  // create an empty tour
  public ExtraCredit() {
  }
  
  // print the tour to standard output
  public void show() {
    if (first != null) {
      Node now = first; 
      StdOut.println(first.p);
      now = first.next;
      while (now != first) {
        StdOut.println(now.p);
        now = now.next;
      }
    }
  }
  
  // draw the tour to standard draw
  public void draw() {
    if (first != null) {
      Node now = first.next;
      first.p.drawTo(now.p);
      while (now != first) {
        now.p.drawTo(now.next.p);
        now = now.next;
      }
    }
  }
  
  // number of points on tour
  public int size() {
    if (first != null) {
      int count = 1;
      Node now = first.next;
      while (now != first) {
        count++;
        now = now.next;
      }
      return count;
    }
    return 0;
  }
  
  // number of points in data
  public int unusedSize() {
    if (data != null) {
      int count = 1;
      Node now = data.next;
      while (now != data) {
        count++;
        now = now.next;
      }
      return count;
    }
    return 0;
  }
  
  // return the total distance of the tour
  public double distance() {
    if (first != null) {
      Node now = first.next;
      double distance = first.p.distanceTo(now.p);
      while (now != first) {
        distance += now.p.distanceTo(now.next.p);
        now = now.next;
      }
      return distance;
    }
    return 0;
  }
  
  // insert a point into the tour before the first point
  public void insertIntoData(Point p) {
    if (data != null) {
      Node originalNext = data.next;
      data.next = new Node();
      data.next.p = p;
      data.next.next = originalNext;
    }
    else {
      data = new Node();
      data.p = p;
      data.next = data;
    }
  }
  
  // insert p using smallest increase heuristic
  public void insertSmallest(Point p) {
    if (first != null) {
      Node closest = first;
      double minDist = Double.POSITIVE_INFINITY;
      Node now = first;
      while (now.next != first) {
        double oldDist = now.p.distanceTo(now.next.p);
        double newDist = now.p.distanceTo(p) + now.next.p.distanceTo(p);
        double delta = newDist - oldDist;
        if (delta < minDist) {
          minDist = delta;
          closest = now;
        }
        now = now.next;
      }
      // when you exit the loop, now = last
      double oldDist = now.p.distanceTo(now.next.p);
      double newDist = now.p.distanceTo(p) + now.next.p.distanceTo(p);
      double delta = newDist - oldDist;
      if (delta < minDist) {
        minDist = delta;
        closest = now;
      }
      
      Node oldNext = closest.next;
      closest.next = new Node();
      closest.next.p = p;
      closest.next.next = oldNext;   
      
    }
    else {
      first = new Node();
      first.p = p;
      first.next = first;
    }
  }
  
  
  // insert p using farthest insertion  heuristic
  public void insertFarthest() {
    if (unusedSize() < 10) {
      // for small tours
      if (data != null) {
        Node now = data.next;
        while (now != data) {
          insertSmallest(now.p);
          now = now.next;
        }
        insertSmallest(now.p);
      }
      return;
    }
    
    // first two
    Node beforeA = data;
    Node beforeB = data;
    Node a = data.next;
    Node b = data.next;
    
    double far = Double.NEGATIVE_INFINITY;
    Node now = data.next;
    Node beforeNow = data;
    while (now != data) {
      Node second = now.next;
      Node beforeSecond = now;
      while (second != data) {
        double distance = now.p.distanceTo(second.p);
        if (distance > far) {
          far = distance;
          a = now;
          beforeA = beforeNow;
          b = second;
          beforeB = beforeSecond;
        }
        second = second.next;
        beforeSecond = beforeSecond.next;
      }
      double distance = now.p.distanceTo(second.p);
      if (distance > far) {
        far = distance;
        a = now;
        beforeA = beforeNow;
        b = second;
        beforeB = beforeSecond;
      }
      now = now.next;
      beforeNow = beforeNow.next;
    }
    Node second = now.next;
    Node beforeSecond = now;
    while (second != data) {
      double distance = now.p.distanceTo(second.p);
      if (distance > far) {
        far = distance;
        a = now;
        beforeA = beforeNow;
        b = second;
        beforeB = beforeSecond;
      }
      second = second.next;
      beforeSecond = beforeSecond.next;
    }
    double distance = now.p.distanceTo(second.p);
    if (distance > far) {
      far = distance;
      a = now;
      beforeA = beforeNow;
      b = second;
      beforeB = beforeSecond;
    }
    
    first = new Node();
    first.p = a.p;
    first.next = new Node();
    first.next.p = b.p;
    first.next.next = first;
    
    if (a.next == b && b.next == a) return;
    else if (a.next == b) beforeA.next = b.next;
    else if (b.next == a) beforeB.next = a.next;
    else {
      beforeA.next = a.next;
      beforeB.next = b.next;
    }
    
    while (data.next != data) {
      // insert everything after the original two
      // which point in data to insert
      Node before = data;
      Node actual = data.next;
      
      // which point in the current tour is being checked
      now = first.next;
      double farthest = Double.NEGATIVE_INFINITY;
      Node beforeInsert = data;
      Node insert = data.next;
      if (data.next.next != data) {
        while (actual != data) {
          double closest = Double.POSITIVE_INFINITY;
          
          while (now != first) {
            double distance2 = actual.p.distanceTo(now.p);
            if (distance2 < closest) {
              closest = distance2;
            }
            now = now.next;
          }
          
          // check first
          double distance2 = actual.p.distanceTo(now.p);
          if (distance2 < closest) closest = distance2;
          if (closest > farthest) {
            farthest = closest;
            insert = actual;
            beforeInsert = before;
          }
          before = before.next;
          actual = actual.next;
        }
        
        // check data (actual = data)
        double closest = Double.POSITIVE_INFINITY;
        now = first.next;
        while (now != first) {
          double distance2 = actual.p.distanceTo(now.p);
          if (distance2 < closest) {
            closest = distance2;
          }
          now = now.next;
        }
        // check first for data (now = first)
        double distance2 = actual.p.distanceTo(now.p);
        if (distance2 < closest) {
          closest = distance2;
        }
        if (closest > farthest) {
          farthest = closest;
          insert = actual;
          beforeInsert = before;
        }
      }
      // insert actual using smallest increase heuristic
      insertSmallest(actual.p);
      // remove actual from data list
      before.next = actual.next;
      if (actual.p == data.p) data = data.next; 
    }
    insertSmallest(data.p);  
  }
  
  
  // swaps nodes if it improves the tour. returns number of switches made.
  public int nodeInterchange() {
    if (size() < 4) return 0;
    int count = 0;
    
    Node a = first;
    
    while (a.next != first) {
      Node b = a.next;
      while (b != first) {
        
        if (a.next != b && b.next != a) {
          // calculate relevant distance from a to b.next.next
          double originalDistance = 0;
          originalDistance += a.p.distanceTo(a.next.p); 
          originalDistance += a.next.p.distanceTo(a.next.next.p);
          originalDistance += b.p.distanceTo(b.next.p);
          originalDistance += b.next.p.distanceTo(b.next.next.p);
          
          // calculate relevant distance from a to b.next.next if
          // a.next and b.next were switched
          
          double newDistance = 0;
          newDistance += a.p.distanceTo(b.next.p); 
          newDistance += b.next.p.distanceTo(a.next.next.p);
          newDistance += b.p.distanceTo(a.next.p);
          newDistance += a.next.p.distanceTo(b.next.next.p);
          
          if (newDistance < originalDistance) {
            // switch points
            // old points
            Node c = a.next;
            Node d = a.next.next;
            Node e = b.next;
            Node f = b.next.next;
            
            a.next = e;
            a.next.next = d;
            b.next = c;
            b.next.next = f;
            
            count++;
          }
        }   
        else if (a.next == b) {
          // calculate relevant distance from a to b.next.next
          double originalDistance = 0;
          originalDistance += a.p.distanceTo(a.next.p); 
          originalDistance += b.next.p.distanceTo(b.next.next.p);
          
          // calculate relevant distance from a to b.next.next if
          // a.next and b.next were switched
          
          double newDistance = 0;
          newDistance += a.p.distanceTo(b.next.p); 
          newDistance += a.next.p.distanceTo(b.next.next.p);
          
          if (newDistance < originalDistance) {
            // old points
            Node c = b.next;
            Node d = b.next.next;
            
            a.next = c;
            a.next.next = b;
            b.next = d;
            
            count++;
          }
        }
        else {
          // calculate relevant distance from a to b.next.next
          double originalDistance = 0;
          originalDistance += b.p.distanceTo(b.next.p); 
          originalDistance += a.next.p.distanceTo(a.next.next.p);
          
          // calculate relevant distance from a to b.next.next if
          // a.next and b.next were switched
          
          double newDistance = 0;
          newDistance += b.p.distanceTo(a.next.p); 
          newDistance += b.next.p.distanceTo(a.next.next.p);
          
          if (newDistance < originalDistance) {
            // old points
            Node c = a.next;
            Node d = b.next.next;
            
            b.next = c;
            b.next.next = a;
            a.next = d;
            
            count++;
          }
        }
        
        // increment b
        b = b.next;  
      }
      // increment a
      a = a.next; 
    }
    return count;
  }
  
  // attach k nearest neighbors to each point in the tour
  public void createNeighbors(int v) {
    if (size() < 10) return;
    k = v;
    Node now = first; 
    now.createNeighbor();
    now = first.next;
    while (now != first) {
      now.createNeighbor();
      now = now.next;
    }
  }
  
  
  // swaps 6 edges if it improves the tour. returns number of switches made.
  public int threeOpt() {
    if (size() < 6) return 0;
    int count = 0;
    
    Node a = first;
    
    while (a.next != first) {
      double aToAnext = a.p.distanceTo(a.next.p);
      for (int i = 0; i < k; i++) {
        Node h = a.next.neighbors[i];
        if (h.p.distanceTo(a.next.p) > aToAnext) break;
        if (a.next != h && h.next != a) {
          double hToHnext = h.p.distanceTo(h.next.p);
          for (int m = 0; m < k; m++) {
            Node b = h.next.neighbors[m];
            if (b.p.distanceTo(h.next.p) > hToHnext) break;
            if (h.next != b && b.next != h && a.next != b 
                  && b.next != a && h != a && b != h) {
              if (switchMeBro(a, b, h, 0)) count++;
            }
          }   
        }
      }
      for (int i = 0; i < k; i++) {
        Node bNext = a.neighbors[i];
        if (bNext.p.distanceTo(a.p) > aToAnext) break;
        Node b = a.next.next;
        while (b.next != bNext) {
          b = b.next;
        }
        if (a.next != b && b.next != a) {
          double bToBnext = b.p.distanceTo(b.next.p);
          for (int m = 0; m < k; m++) {
            Node h = b.neighbors[m];
            if (b.p.distanceTo(h.p) > bToBnext) break;
            if (h.next != b && b.next != h && a.next != h && h.next != a && h != a) {
              if (switchMeBro(a, b, h, 1)) count++;
            }
          }   
        }
      }
      a = a.next;
    }
    return count;
  }  
  
  // switch them if it's proper to do so
  public boolean switchMeBro(Node a, Node b, Node h, int o)  {
    boolean switched = false;
    // calculate relevant original distances
    double originalDistance = 0;
    originalDistance += a.p.distanceTo(a.next.p); 
    originalDistance += b.p.distanceTo(b.next.p);
    originalDistance += h.p.distanceTo(h.next.p);
    
    // calculate relevant distances if the edges were switched
    
    double newDistance = 0;
    newDistance += a.p.distanceTo(b.next.p); 
    newDistance += a.next.p.distanceTo(h.p);
    newDistance += b.p.distanceTo(h.next.p);
    
    double newDistance2 = 0;
    newDistance2 += a.p.distanceTo(b.next.p); 
    newDistance2 += a.next.p.distanceTo(h.next.p);
    newDistance2 += b.p.distanceTo(h.p);
    
    if (b.p.distanceTo(h.next.p) < b.p.distanceTo(b.next.p) 
          && newDistance < originalDistance 
          && newDistance < newDistance2) {
      // switch points
      // old points
      
      Node c = a.next;
      Node d = b.next;
      Node j = h.next;
      
      // check to make sure b comes before h
      boolean bad = false;
      Node q = a.next;
      while (q != b) {
        if (q == h) {
          bad = true;
          break;
        }
        q = q.next;
      }
      
      if (!bad) {
        a.next = d;
        h.next = c;
        b.next = j;
        switched = true;
      }
    }
    else if (b.p.distanceTo(h.p) < b.p.distanceTo(b.next.p) 
               && newDistance2 < originalDistance 
               && newDistance2 < newDistance) {
      // switch points
      // old points
      
      Node c = a.next;
      Node d = b.next;
      Node j = h.next;
      
      // check to make sure b comes before h
      boolean bad = false;
      Node q = a.next;
      while (q != b) {
        if (q == h) {
          bad = true;
          break;
        }
        q = q.next;
      }
      
      if (!bad) {
        Node e = c;
        Node f = c.next.next;
        Node g = c.next;
        
        a.next = d;
        h.next = b;
        c.next = j;
        
        while (e != b) {
          g.next = e;
          e = g;
          g = f;
          f = f.next;
        }
        switched = true;
      }
    }
    return switched;
  }
  
  // main method for testing
  public static void main(String[] args) {
    // define 4 points forming a square
    Point a = new Point(100.0, 100.0);
    Point b = new Point(500.0, 100.0);
    Point c = new Point(500.0, 500.0);
    Point d = new Point(100.0, 500.0);
    
    // Set up a Tour with those four points
    // The constructor should link a->b->c->d->a
    Tour squareTour = new Tour(a, b, c, d);
    
    // Output the Tour
    squareTour.show();
    StdOut.println(squareTour.size());
    StdOut.println(squareTour.distance());
    StdDraw.setXscale(0, 600);
    StdDraw.setYscale(0, 600);
    squareTour.draw();
  }
}
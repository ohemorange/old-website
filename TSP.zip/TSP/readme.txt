Running Instructions:
java ExtraCreditRunner k < input.txt > output.txt
k is the number of neighbors to search in 3-opt.
k must be less than the size of the tour.
15 gives generally good results.
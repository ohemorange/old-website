/******************************************************************************
  * Erica Portnoy
  * login: eportnoy
  * Precept: P02C
  * assignment 8
  * 
  * Compilation: javac ExtraCreditRunner.java
  * Execution: java ExtraCreditRunner < tsp1000.txt k
  * Dependencies: StdIn.java, StdOut.java, StdDraw.java, Point.java, 
  *               ExtraCredit.java
  * 
  * Explanation: Run farthest insertion heuristic for traveling salesperson 
  * problem, perform node and edge interchange heuristics to improve path until
  * exchanges will no longer improve path, and plot results.
  * k must be < size.
  ******************************************************************************/

public class ExtraCreditRunner {

    public static void main(String[] args) {

        // get dimensions
        int w = StdIn.readInt();
        int h = StdIn.readInt();
        StdDraw.setCanvasSize(w, h);
        StdDraw.setXscale(0, w);
        StdDraw.setYscale(0, h);

        // turn on animation mode
        StdDraw.show(0);

        ExtraCredit tour = new ExtraCredit();
        
        // collect points
        while (!StdIn.isEmpty()) {
            double x = StdIn.readDouble();
            double y = StdIn.readDouble();
            Point p = new Point(x, y);
            tour.insertIntoData(p);
        }
        // create tour
        tour.insertFarthest();
        
        // attach k nearest neighbors to each point in the tour
        tour.createNeighbors(Integer.parseInt(args[0]));
        
        // optimize tour
        int num1 = 1;
        
        while (num1 != 0) {
          num1 = tour.threeOpt();       
          int num3 = 1;
          while (num3 != 0) {
            num3 = tour.nodeInterchange();
          }
          num3 = 1;
        }
        
        // draw to standard draw 
        StdDraw.clear();
        tour.draw();
        StdDraw.show(500);
        
        // print tour to standard output
        StdOut.printf("Tour distance =  %.4f\n", tour.distance());
        StdOut.printf("Number of points = %d\n", tour.size());
        //tour.show();
    }

}

/******************************************************************************
  * Erica Portnoy
  * login: eportnoy
  * Precept: P02C
  * assignment 5
  * 
  * Compilation: javac LFSR.java
  * Execution: java LFSR
  * Dependencies: n/a
  * 
  * Explanation: Data type that simulates the operation of a LFSR
  ******************************************************************************/

public class LFSR {
  // declare instance variables
  private int N;       // number of bits in the LFSR
  private int[] reg;   // reg[i] = ith bit of LFSR, reg[0] is rightmost bit
  private int tap;     // index of the tap bit
  
  // constructor to create LFSR with the given initial seed and tap
  public LFSR(String seed, int t) {
    N = seed.length();
    tap = t;
    reg = new int[N];
    int j = 0;
    // enters values into array to correspond with LFSR numbering
    for (int i = N-1; i >= 0; i--) {
      reg[i] = Integer.parseInt(seed.substring(j, j+1));
      j++;
    }
  }
  
  // simulate one step and return the new bit as 0 or 1
  public int step() {
    int leftmost = reg[N-1];
    int t = reg[tap];
    int newBit = leftmost ^ t;
    for (int i = N-2; i >= 0; i--) {
      reg[i+1] = reg[i];
    }
    reg[0] = newBit;
    return newBit;
  }
  
  // simulate k steps and return k-bit integer
  public int generate(int k) {
    int sum = 0;
    for (int i = 0; i < k; i++) {
      sum = 2 * sum + step();
    }
    return sum;
  }
  
  // return a string representation of the LFSR
  public String toString()  {
    String s = "";
    for (int i = 0; i < N; i++) {
      s = reg[i] + s;
    }
    return s;
  }
  
  
  // test client
  public static void main(String[] args)  {
    LFSR lfsr = new LFSR("01101000010", 8);
    StdOut.println(lfsr);
    for (int i = 0; i < 10; i++) {
      int bit = lfsr.step();
      StdOut.println(lfsr + " " + bit);
    }
    
    LFSR lfsr2 = new LFSR("01101000010", 8);
    for (int i = 0; i < 10; i++) {
      int r = lfsr2.generate(5);
      StdOut.println(lfsr2 + " " + r);
    }
  }
  
}

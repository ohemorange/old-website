/******************************************************************************
  * Erica Portnoy
  * login: eportnoy
  * Precept: P02C
  * assignment 5
  * 
  * Compilation: javac PhotoMagic.java
  * Execution: java PhotoMagic pipe.png 01101000010100010000 16
  * Dependencies: Color.java, LFSR.java, Picture.java
  * 
  * Explanation: Encrypts and decrypts pictures using LFSR.
  ******************************************************************************/
import java.awt.Color;

public class PhotoMagic {
  
  //  transform picture using lfsr
  public static Picture transform(Picture picture, LFSR lfsr) {
    int height = picture.height();
    int width = picture.width();
    
    Picture newPic = new Picture(width, height);
    
    for (int x = 0; x < width; x++) {
      for (int y = 0; y < height; y++) {
        Color c = picture.get(x, y);
        int r = c.getRed();
        int g = c.getGreen();
        int b = c.getBlue();
        
        r ^= lfsr.generate(8);
        g ^= lfsr.generate(8);
        b ^= lfsr.generate(8);
        
        Color newC = new Color(r, g, b);
        newPic.set(x, y, newC);
      }
    }       
    
    return newPic;
  }
  
  //  read in the name of a picture and the description of an LFSR
  //  from the command-line and encrypt the picture with the LFSR
  //  display the encrypted version of the picture
  public static void main(String[] args) {
    
    Picture pic = new Picture(args[0]);
    LFSR lfsr = new LFSR(args[1], Integer.parseInt(args[2]));
    
    Picture encoded = transform(pic, lfsr);
    encoded.show();
  }
}
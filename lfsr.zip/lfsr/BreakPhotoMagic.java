/******************************************************************************
  * Erica Portnoy
  * login: eportnoy
  * Precept: P02C
  * assignment 5
  * 
  * Compilation: javac BreakPhotoMagic.java
  * Execution: java BreakPhotoMagic Xpipe.png 10
  * Dependencies: Color.java, LFSR.java, Picture.java, PhotoMagic.java,
  *               PhotoMagicDeluxe.java,
  * 
  * Explanation: Breaks encryption of pictures encrypted using LFSR.
  * To return original image, assumes LFSR seed is long enough such that pixels
  * of encrypted image are pseudo-random.
  ******************************************************************************/
import java.awt.Color;

public class BreakPhotoMagic {
  
  public static final int MEDIAN = 128; // median of RGB value range
  
  //returns average of R, G, and B values throughout entire image
  public static int test(Picture picture, LFSR lfsr) {
    int height = picture.height();
    int width = picture.width();
    
    Picture newPic = new Picture(width, height);
    
    int sum = 0;
    int count = 0;
    
    for (int x = 0; x < width; x++) {
      for (int y = 0; y < height; y++) {
        Color c = picture.get(x, y);
        int r = c.getRed();
        int g = c.getGreen();
        int b = c.getBlue();
        
        r ^= lfsr.generate(8);
        g ^= lfsr.generate(8);
        b ^= lfsr.generate(8);
        
        sum = sum + r + b + g;
        count++;
        
        Color newC = new Color(r, g, b);
        newPic.set(x, y, newC);
      }
    }       
    
    return (int) (sum / count / 3);
  }  
  
  // converts int index to a binary String of length N
  private static String intToNBin(int index, int N) {      
    String bin = "";
    
    int i = index;
    
    // convert index to binary string
    while (i > 0) {
      bin = i % 2 + bin;
      i /= 2;
    }
    
    // make sure it has N digits
    for (int j = bin.length(); j < N; j++)
      bin = 0 + bin;
    
    return bin;
  }
  
  public static void main(String[] args) {
    
    Picture pic = new Picture(args[0]);
    
    //number of bits
    int N = Integer.parseInt(args[1]);
    
    String seed = "";
    int tap = 0;
    
    int running = MEDIAN;
    
    for (int i = 1; i < Math.pow(2, N); i++) { //for all seeds of length N
      String currSeed = intToNBin(i, N); 
      for (int j = 0; j < N; j++) { //for all taps in that seed
        LFSR lfsr = new LFSR(currSeed, j);
        int curr = test(pic, lfsr);
        if (Math.abs(curr - 128) > Math.abs(running - 128)) {
          running = curr;
          seed = currSeed;
          tap = j;
        }
      }
    }
    
    LFSR lfsr = new LFSR(seed, tap);
    Picture encoded = PhotoMagic.transform(pic, lfsr);
    encoded.show();
    
  }
}
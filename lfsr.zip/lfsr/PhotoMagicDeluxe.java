/******************************************************************************
  * Erica Portnoy
  * login: eportnoy
  * Precept: P02C
  * assignment 5
  * 
  * Compilation: javac PhotoMagicDeluxe.java
  * Execution: java PhotoMagicDeluxe Xjava.png OPENSESAME 58
  * Dependencies: LFSR.java, Picture.java, PhotoMagic.java
  * 
  * Explanation: Encrypts and decrypts pictures using LFSR.
  *              Uses an alphanumeric password instead of binary.
  ******************************************************************************/
public class PhotoMagicDeluxe {
  // number of bits in binary representation of each alphanumeric character
  private static final int BITS = 6; 
  
  // transform picture using lfsr
  public static Picture transform(Picture picture, LFSR lfsr) {
    return PhotoMagic.transform(picture, lfsr);
  }
  
  // transform picture using alphanumeric passcode
  // still can't be called from outside client
  private static Picture transform(Picture picture, String pass, int tap) {
    LFSR lfsr = new LFSR(convert(pass), tap);
    return PhotoMagic.transform(picture, lfsr);
  }
  
  // converts int index to a binary String of length N
  private static String intToNBin(int index, int N) {      
    String bin = "";
    
    int i = index;
    
    // convert index to binary string
    while (i > 0) {
      bin = i % 2 + bin;
      i /= 2;
    }
    
    // make sure it has N digits
    for (int j = bin.length(); j < N; j++)
      bin = 0 + bin;
    
    return bin;
  }
  
  // convert N-character alphanumeric password 
  // to 6N-character binary password
  private static String convert(String alpha) {
    String base64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" 
      + "abcdefghijklmnopqrstuvwxyz0123456789+/";
    String pass = "";
    for (int i = 0; i < alpha.length(); i++) {
      char c = alpha.charAt(i);
      // find index of c in string above
      int index = base64.indexOf(c);
      
      pass += intToNBin(index, BITS);
    }
    return pass;
  }
  
  //  read in the name of a picture and the description of an LFSR
  //  from the command-line and encrypt the picture with the LFSR
  //  display the encrypted version of the picture
  public static void main(String[] args) {
    
    Picture pic = new Picture(args[0]);
    String pass = args[1];
    int tap = Integer.parseInt(args[2]);
    
    Picture encoded = transform(pic, pass, tap);
    encoded.show();
  }
}